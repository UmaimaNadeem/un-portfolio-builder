<?php $__env->startSection('content'); ?>
<div class="unMainContainer">
    <h1>3D Models</h1>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success mt-2" id="success-alert">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('armodels.create')); ?>" class="btn btn-primary mb-3">Add New Model</a>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Link</th>
                <th>Media</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $arModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $armodel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($armodel->id); ?></td>
                    <td><?php echo e($armodel->title); ?></td>
                    <td><?php echo e($armodel->description); ?></td>
                    <td><a href="<?php echo e($armodel->link); ?>" target="_blank">Project Link</a></td>
                    <td>
                        <?php if($armodel->media): ?>
                            <?php if(Str::endsWith($armodel->media, ['.jpg', '.jpeg', '.png'])): ?>
                                <img src="<?php echo e(url($armodel->media)); ?>" alt="Project Media" style="width: 100px;">
                            <?php else: ?>
                                <video width="100" controls>
                                    <source src="<?php echo e(url($armodel->media)); ?>" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('armodels.show', $armodel->id)); ?>" class="btn btn-info btn-sm">View</a>
                        <a href="<?php echo e(route('armodels.edit', $armodel->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('armodels.destroy', $armodel->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mySites\un-portfolio-builder\resources\views/pages/admin/armodels/index.blade.php ENDPATH**/ ?>