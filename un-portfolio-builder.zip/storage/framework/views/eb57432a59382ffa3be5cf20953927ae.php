<?php $__env->startSection('content'); ?>
<div class="unMainContainer">
    <h2>Services</h2>
    <a href="<?php echo e(route('services.create')); ?>" class="btn btn-primary mb-3">Add New</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Icon</th>
                <th>Name</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><i class="<?php echo e($service->icon); ?>"></i></td>
                <td><?php echo e($service->name); ?></td>
                <td><?php echo e($service->status ? 'Active' : 'Inactive'); ?></td>
                <td>
                    <a href="<?php echo e(route('services.edit', $service->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="<?php echo e(route('services.show', $service->id)); ?>" class="btn btn-sm btn-info">View</a>
                    <form action="<?php echo e(route('services.destroy', $service->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mySites\un-portfolio-builder\resources\views/pages/admin/services/index.blade.php ENDPATH**/ ?>