<?php $__env->startSection('content'); ?>
<div class="unMainContainer">
    <h2 class="mb-4">User Profile Links</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('user-profile-links.create')); ?>" class="btn btn-primary mb-3">Add New Profile</a>

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Website</th>
                <th>Stack</th>
                <th>Portfolio</th>
                <th>GitHub</th>
                <th>LinkedIn</th>
                <th>CV/Resume</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $userProfileLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($link->website_name); ?></td>
                    <td><?php echo e($link->stack); ?></td>
                    <td>
                        <?php if($link->portfolio_link): ?>
                            <a href="<?php echo e($link->portfolio_link); ?>" target="_blank">View</a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($link->github): ?>
                            <a href="<?php echo e($link->github); ?>" target="_blank">GitHub</a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($link->linkedin): ?>
                            <a href="<?php echo e($link->linkedin); ?>" target="_blank">LinkedIn</a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($link->cv_resume): ?>
                            <a href="<?php echo e(asset($link->cv_resume)); ?>" target="_blank">Download</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('user-profile-links.show', $link->id)); ?>" class="btn btn-sm btn-info">View</a>
                        <a href="<?php echo e(route('user-profile-links.edit', $link->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('user-profile-links.destroy', $link->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center">No profile links found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mySites\un-portfolio-builder\resources\views/pages/admin/userProfileLinks/index.blade.php ENDPATH**/ ?>