<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="btn btn-toggle" id="sidebarToggleBtn">
        <i class="fa fa-bars"></i>
    </button>

    <ul class="navbar-nav ms-auto">
        <li class="nav-item dropdown pe-3">
            <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="<?php echo e(asset('assets/img/images.jpg')); ?>" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo e(Auth::user()->name); ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
                <h6><?php echo e(Auth::user()->name); ?></h6>
                <span><?php echo e(Auth::user()->role); ?></span>
            </li>

            <li>
                <hr class="dropdown-divider">
            </li>

            <li>
                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('profile.show')); ?>">
                    <i class="bi bi-person"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li>
                <hr class="dropdown-divider">
            </li>
            <li>
                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('logout')); ?>">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
                </a>
            </li>

            </ul>
            </li>
    </ul>
</nav>

<?php /**PATH D:\mySites\un-portfolio-builder\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>