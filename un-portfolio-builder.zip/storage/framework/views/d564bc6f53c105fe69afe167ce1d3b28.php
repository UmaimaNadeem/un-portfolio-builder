<?php $__env->startSection('content'); ?>
<div class="unMainContainer">
    <h2>Personal Info List</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('personal_info.create')); ?>" class="btn btn-primary mb-3">Add New</a>

    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $personalInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($info->profile_image): ?>
                        <img src="<?php echo e(asset('content/' . $info->user_id . '/profile/' . $info->profile_image)); ?>" width="60">
                        <?php else: ?>
                            <span>No Image</span>
                        <?php endif; ?>
                    </td>
                    
                    <td><?php echo e($info->name); ?></td>
                    <td><?php echo e($info->email); ?></td>
                    <td><?php echo e($info->phone); ?></td>
                    <td><?php echo e($info->address); ?></td>
                    <td>
                        <a href="<?php echo e(route('personal_info.show', $info->id)); ?>" class="btn btn-info btn-sm">View</a>
                        <a href="<?php echo e(route('personal_info.edit', $info->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('personal_info.destroy', $info->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">No records found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mySites\un-portfolio-builder\resources\views/pages/admin/personal_info/index.blade.php ENDPATH**/ ?>