<?php $__env->startSection('content'); ?>
<div class="unMainContainer">
    <h1>My Portfolio</h1>
    <p class="mt-4">Click the link below to get access to your portfolio for yoyur added data</p>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success mt-2" id="success-alert">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <a href="http://un-portfolio-builder.test/admin/portfolio/1'" class="btn btn-primary mb-3">View Your Portfolio</a>       
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mySites\un-portfolio-builder\resources\views/pages/admin/portfolios/index.blade.php ENDPATH**/ ?>